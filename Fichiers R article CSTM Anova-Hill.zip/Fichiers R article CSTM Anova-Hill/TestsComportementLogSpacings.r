# 4 juin 2012
#
# Le but de ce code est de se rassurer sur le comportement des Y_i = i log(X_{n-i+1,n}/X_{n,i})
# dans le but de voir si la moyenne de leur carr�-centr� converge bien vers gamma^2 
# (condition indispensable pour que la m�thode EL fonctionne, et pour l'instant n�buleuse 
# car la preuve de Peng d�conne)
#
# L'objectif est de voir si, quand n cro�t, la moyenne des (Y_i - Hill)^2  converge vers gamma^2
# Pour ce faire, on va regarder une trajectoire par "valeur de kn" (c�d expression de kn en fonction de n)
# chaque trajectoire fonction de n d�crivant la valeur de Hill et de (1/k(n)) sum( (Y_i - Hill)^2 )

setwd("F:\\Recherche\\Extr�mes\\ArtAnovaHill")
#source("el.testAnnote.R")   
#library(evd)

vecn=seq(500,10000,by=500)
lvecn=length(vecn)

n=vecn[lvecn]

# On g�n�re l'�chantillon totale de tr�s grande taille : on prendra un morceau de plus en plus gros de cet �chantillon

# Burr
#thet1=10 ;  tau1=1; lam1=1   ;  vraigam1=1/(lam1*tau1)  ;  vrairho1=-1/lam1  ;  Xcomplet=(thet1*(1-runif(n))^(-1/lam1)-thet1)^(1/tau1)    # Loi de Burr
# Frechet
vraigam1=1     ; vrairho1=-1 ;   Xcomplet = (-log(runif(n)))^(-vraigam1)                   # Loi de Frechet

# Choix des valeurs de kn
# 
# Pour n fix�, on va prendre variant entre 1/10 et 10/10 d'une valeur �gale � une portion de plus en plus petite de n
# disons kn varie entre 1/15 et 15/15 de 300=1000*3/10 quand n vaut 1000, et de 1000=10000*1/10 quand n vaut 10000 . 
# c�d kn varie entre 20 et 300 quand n vaut 1000, et entre 1000/15=70 et 1000 quand n vaut 10000

portion = seq(1/10,3/10,length=lvecn)

Hill = matrix ( rep(0,lvecn*15) , 15 , lvecn )
Yquadr = Hill

for (i in 1:lvecn) { 

n=vecn[i]
X=Xcomplet[1:n]
X=sort(X)
veckn = floor(  ((1:15)/15)*(n*portion[i]) )   # c'est un vecteur de valeurs croissantes de kn
Xnmip1 = X[n:(n-veckn[15]+1)]
Xnmi   = X[(n-1):(n-veckn[15])]

for (j in 1:15) { 
 kn = veckn[j]
 Y = (1:kn) * log ( Xnmip1[1:kn] / Xnmi[1:kn] )
 Hill[j,i] = mean(Y)
 Yquadr[j,i]  = mean( (Y-Hill[j,i])^2 ) 
 }

}

par(mfrow=c(1,2))
plot(vecn,Hill[1,],type='l',col=1,ylim=c(0.5,1.5),ylab='valeur de Hill',xlab='valeur de n')
for (j in 2:15) {
lines(vecn,Hill[j,],type='l',col=j)
}
plot(vecn,Yquadr[1,],type='l',col=1,ylim=c(-1,1),ylab='valeur de Yquadr',xlab='valeur de n')
for (j in 2:15) {
lines(vecn,Yquadr[j,]-vraigam1^2,type='l',col=j)
}

