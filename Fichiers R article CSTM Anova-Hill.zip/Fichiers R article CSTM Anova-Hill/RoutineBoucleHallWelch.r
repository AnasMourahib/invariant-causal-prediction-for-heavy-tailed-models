# Fichier permettant de faire tourner en boucle pour une s�lection de couples de mod�les
# notre test de comparaison avec s�lection automatique de kopt via la "proc�dure de Hall & Welsh"
# Le r�sultat obtenu est une �valuation du niveau (ou de la puissance, suivant que vgam1 a �t� pris = vgam2 ou non)
# pour chacun des niveaux nominaux 5% et 10%, et chacun des couples de lois choisis.
#
# Attention : les valeurs de N,n,m sont � sp�cifier dans le fichier "TestComparaisonDeuxGammasPositifsOptimalHallWelsh.R"
#
# Pour sortir toutes pr�tes les lignes � int�grer dans un fichier .tex, sourcer ensuite le fichier "AffichageResultatsFormatLaTeX.R"

# Ce code permet de calculer des risques r�els simul�s (version="Niveau") ou des puissances simul�es (version="Puissance")
# ou bien permet de faire tourner une seule configuration, niveau ou puissance (version="couple"), � sp�cifier ci-dessous.

version= "Puissance" #  "Niveau"  #  "couple" #  

affichagedetaille="non" # indiquer "oui" si l'on veut l'affichage du d�tail par couple de lois


# Simulations de niveau : celles de Mougeot & Tribouley (sauf mod�le de Pareto-Hall)

if (version=="Niveau")
{
# version avec seulement des Student impliqu�es 

noms1=c("Student","Student","Student", "Student","Student", "Student","Student","Student")
noms2=c("Student","Student","Student", "Fr�chet","Fr�chet", "Burr","Burr","Burr")
vgam1s=c(1/4,1/2,1,      1/2,1,   1/2,1,1)
vgam2s=c(1/4,1/2,1,      1/2,1,   1/2,1,1)
vrho1s=c(-1/2,-1,-2,     -1,-2,  -1,-2,-2)
vrho2s=c(-1/2,-1,-2,     -1,-1,  -1/2,-1,-2)
noms=c("tt","tt","tt","tF","tF","tB","tB","tB")

# version avec tous les couples de lois choisis pour la comparaison avec MT

noms1=c("Student","Student","Student", "Fr�chet","Fr�chet","Fr�chet", "Burr","Burr","Burr","Burr", "Student","Student", "Student","Student","Student", "Fr�chet","Fr�chet","Fr�chet","Fr�chet","Fr�chet","Fr�chet")
noms2=c("Student","Student","Student", "Fr�chet","Fr�chet","Fr�chet", "Burr","Burr","Burr","Burr", "Fr�chet","Fr�chet", "Burr","Burr","Burr",          "Burr","Burr","Burr","Burr","Burr","Burr")
vgam1s=c(1/4,1/2,1, 1/4,1/2,1,  1/4,1/4,1,1,    1/2,1,  1/2,1,1,   1/4,1/2,1,1/4,1/2,1)
vgam2s=c(1/4,1/2,1, 1/4,1/2,1,  1/4,1/4,1,1,    1/2,1,  1/2,1,1,   1/4,1/2,1,1/4,1/2,1)
vrho1s=c(-1/2,-1,-2, -1,-1,-1,   -2,-1,-1,-2,    -1,-2, -1,-2,-2,   -1,-1,-1,-1,-1,-1)
vrho2s=c(-1/2,-1,-2, -1,-1,-1,   -2,-2,-1,-2,    -1,-1, -1/2,-1,-2, -1,-1,-1,-2,-2,-2)
noms=c("tt","tt","tt","FF","FF","FF","BB","BB","BB","BB","tF","tF","tB","tB","tB","FB","FB","FB","FB","FB","FB")
}

# Simulations de puissance : celles de Mougeot & Tribouley (sauf mod�le de Pareto-Hall)

if (version=="Puissance") 
{
noms1=c("Student","Student","Student", "Fr�chet","Fr�chet", "Burr","Burr","Burr","Burr", "Student","Student","Student","Student")
noms2=c("Student","Student","Student", "Fr�chet","Fr�chet", "Burr","Burr","Burr","Burr", "Fr�chet","Fr�chet","Fr�chet","Fr�chet")
vgam1s=c(1/4,1/4,1/2,  1/4,1/4,  1/4,1/4,1/4,1/4,  1/4,1/2,1,1)
vgam2s=c(1/2, 1 , 1 ,  1/2, 1 ,  1/2, 1 ,1/2,1/2,  1 ,1/4,1/4,1/2)
vrho1s=c(-1/2,-1/2,-1,  -1,-1,  -1/2,-1/2,-1,-1,  -1/2,-1,-2,-2)
vrho2s=c(-1  ,-2  ,-2,  -1,-1,  -1/2,-1/2,-1/2,-2,  -1,-1,-1,-1)
noms=c("tt","tt","tt","FF","FF","BB","BB","BB","BB","tF","tF","tF","tF")
}

if (version=="couple") # Essai  avec un seul couple de mod�les
{
noms1=c("Student")
noms2=c("Student")
vgam1s=c(1/4)
vgam2s=c(1/4)
vrho1s=c(-1/2)
vrho2s=c(-1/2)
}

numeroducas = 1

vecpuissance5 = rep(0,length(noms1))
vecpuissance10=vecpuissance5
k1optimal = vecpuissance5
k2optimal = vecpuissance5


while (numeroducas <= length(noms1)) {


nom1=noms1[numeroducas] ; nom2=noms2[numeroducas]
vgam1=vgam1s[numeroducas] ; vgam2=vgam2s[numeroducas]
vrho1=vrho1s[numeroducas] ; vrho2=vrho2s[numeroducas]

source("C:/Users/Julien/Roulio/Recherche/Extr�mes/ArtAnovaHill/TestComparaisonDeuxGammasPositifsOptimalHallWelsh.R")
#source("C:/Users/Julien/Roulio/Recherche/Extr�mes/ArtAnovaHill/TestComparaisonDeuxGammasPositifsOptimalHallWelsh_VersionRymJuin2012.R")


vecpuissance5[numeroducas]  = 100*mean( Qmuchap > qchisq(0.95,1) ) 
vecpuissance10[numeroducas] = 100*mean( Qmuchap > qchisq(0.90,1) ) 

if (affichagedetaille=="oui") 
{
cat("Premi�re loi ",nom1,"(",vgam1,", rho=",vrho1,"),  Seconde Loi ",nom2,"(",vgam2,", rho=",vrho2,"), n=",n,", m=",m,", nb simuls=",N,"\n")
cat("R�partition des nombres de valeurs n�gatives dans X1 : \n")
print(summary(vecnbneg1))
cat("R�partition des valeurs optimales de k1rho trouv�es : \n")
print(summary(valkrhoopt1))
cat("R�partition des valeurs optimales de k2rho trouv�es : \n")
print(summary(valkrhoopt2))
cat("R�partition des valeurs des estimations de rho1=",vrho1," trouv�es : \n")
print(summary(vecchaprho1))
cat("R�partition des valeurs des estimations de rho2=",vrho2," trouv�es : \n")
print(summary(vecchaprho2))
cat("R�partition des valeurs optimales de k1 trouv�es : \n")
print(summary(k1optimal))
cat("R�partition des valeurs optimales de k2 trouv�es : \n")
print(summary(k2optimal))
cat("R�partition des valeurs des estimations de gamma1=",vgam1," trouv�es : \n")
print(summary(vecHill1opt))
cat("R�partition des valeurs des estimations de gamma2=",vgam2," trouv�es : \n")
print(summary(vecHill2opt))
if (vgam1 != vgam2){
 cat("Evaluation de la puissance de la proc�dure pour alpha =",100*alpha,"% : ",puissance , "\n\n")
 }
if (vgam1 == vgam2){
 cat("Evaluation du niveau de la proc�dure pour alpha =",100*alpha,"% : ",puissance , "\n\n")
 }
}

numeroducas = numeroducas + 1

} # fin du while

# Affichage synth�tique des r�sultats 

if (version=="Niveau")
{
# version complete
valMT5 =c(6,11,9,1,2,3,3,14,9,14,33,7,16,10,8,12,10,14,3,2,3) 
valMT10=c(17,25,20,8,9,10,10,28,19,29,57,16,36,22,20,28,24,26,10,9,10) 
# version avec seulement Student
#valMT5 =c(6,11,9,33,7,16,10,8) 
#valMT10=c(17,25,20,57,16,36,22,20) 
cat("Comparaison des valeurs des niveaux pour alpha=5% (ligne 1 = WW, ligne 2 = MT)\n ")
matniv=matrix(c(vecpuissance5,valMT5),2,length(noms1),byrow=T)
matniv=as.data.frame(matniv) ; names(matniv)=noms
print(matniv)
cat("Comparaison des valeurs des niveaux pour alpha=10% (ligne 1 = WW, ligne 2 = MT)\n ")
matniv=matrix(c(vecpuissance10,valMT10),2,length(noms1),byrow=T)
matniv=as.data.frame(matniv) ; names(matniv)=noms
print(matniv)
}



if (version=="Puissance")
{
valMT5 =c(20,62,39,61,94,82,100,98,40,45,98,100,82) 
valMT10=c(35,82,61,85,99,94,100,100,67,68,99,100,95) 
#matpuiss=matrix(c(vecpuissance,valMT),2,length(noms1),2,byrow=T)
cat("Comparaison des valeurs de puissance pour alpha=5% (ligne 1 = WW, ligne 2 = MT)\n ")
matniv=matrix(c(vecpuissance5,valMT5),2,length(noms1),byrow=T)
matniv=as.data.frame(matniv) ; names(matniv)=noms
print(matniv)
cat("Comparaison des valeurs des puissance pour alpha=10% (ligne 1 = WW, ligne 2 = MT)\n ")
matniv=matrix(c(vecpuissance10,valMT10),2,length(noms1),byrow=T)
matniv=as.data.frame(matniv) ; names(matniv)=noms
print(matniv)
}


