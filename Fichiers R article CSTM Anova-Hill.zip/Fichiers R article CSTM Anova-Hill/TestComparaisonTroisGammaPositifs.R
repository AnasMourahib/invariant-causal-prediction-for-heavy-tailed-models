# Version  28 juin 2013 
#  Mise en oeuvre de notre test de comparaison de trois Gamma Positifs � l'aide de l'ANOVA appliqu�e 
#  � l'estimateur de Hill. Code r�dig� suite � la demande du rapporteur de donner un exemple � trois.
# 
#  Tout ce code est bas� sur la m�me m�thode que le fichier "TestComparaisonDeuxGammasPositifsOptimalHallWelsh.R"
#  mais pour trois �chantillons. 
#
# En entr�e : n, le nb de simuls N, les noms des 3 lois compar�es, les valeurs vgam1,vgam2,vgam3,vrho1,vrho2,vrho3
# En sortie : pour chaque simul, la valeur de la statq Qmuchap, etc... (voir d�tails dans fichier sus-cit�)

library(evd)

affichagedetaille="oui"

N=2000 
n=1000  
m=700
o=500  

alpha=0.05 ; chideux1=qchisq(1-alpha,2) # 3-1=2 ddl car 3 groupes

nom1=c("Burr") ; nom2=c("Burr") ; nom3=c("Burr")  
vgam1=c(1/2) ; vgam2=c(1/2) ; vgam3=c(1/2)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-1)

nom1=c("Fr�chet") ; nom2=c("Burr") ; nom3=c("Burr")  
vgam1=c(0.45) ; vgam2=c(0.75) ; vgam3=c(1/2)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-1)

nom1=c("Burr") ; nom2=c("Burr") ; nom3=c("Burr")  
vgam1=c(1/2) ; vgam2=c(0.5) ; vgam3=c(1/2)
vrho1=c(-0.1) ; vrho2=c(-0.1) ; vrho3=c(-0.1)

nom1=c("Fr�chet") ; nom2=c("Fr�chet") ; nom3=c("Fr�chet")  
vgam1=c(1/4) ; vgam2=c(1/4) ; vgam3=c(1/4)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-1)

nom1=c("Fr�chet") ; nom2=c("Fr�chet") ; nom3=c("Fr�chet")  
vgam1=c(0.45) ; vgam2=c(0.5) ; vgam3=c(1/2)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-1)

nom1=c("Fr�chet") ; nom2=c("Burr") ; nom3=c("Burr")  
vgam1=c(0.5) ; vgam2=c(0.5) ; vgam3=c(1/2)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-1)

nom1=c("Fr�chet") ; nom2=c("Burr") ; nom3=c("Student")  
vgam1=c(1) ; vgam2=c(1) ; vgam3=c(1)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-2)

nom1=c("Fr�chet") ; nom2=c("Fr�chet") ; nom3=c("Fr�chet")  
vgam1=c(0.8) ; vgam2=c(1) ; vgam3=c(1)
vrho1=c(-1) ; vrho2=c(-1) ; vrho3=c(-1)


valkrho1=round(min(n-1,2*n^(0.995)/log(log(n))))   
valkrho2=round(min(m-1,2*m^(0.995)/log(log(m))))   
valkrho3=round(min(o-1,2*o^(0.995)/log(log(o))))   # choix des k pour estimer les rho_j  

nb=0  # valeur initiale 
muchap = rep(0,N) # contient les valeurs de muchap
Qmuchap = rep(0,N) # contient les valeurs de Q(muchap,muchap)

valkrhoopt1=rep(0,N)
valkrhoopt2=rep(0,N)
valkrhoopt3=rep(0,N)
vecnbneg1=rep(0,N)
vecchaprho1=rep(0,N)
vecchaprho2=rep(0,N)
vecchaprho3=rep(0,N)
k1optimal=rep(0,N)
k2optimal=rep(0,N)
k3optimal=rep(0,N)
vecHill1opt=rep(0,N)
vecHill2opt=rep(0,N)
vecHill3opt=rep(0,N)


for (i in  1:N) {    # on simule N n-echantillons
  
# Choix de la premiere loi (celle de X1) 

if (nom1=="Burr"){ 
# Burr
gamma1=vgam1 ; rho1=vrho1  ;  thet1=1 ;  tau1=-rho1/gamma1; lam1=-1/rho1    ;  X1=(thet1*(1-runif(n))^(-1/lam1)-thet1)^(1/tau1)   
}
if (nom1=="Fr�chet"){                         
# Frechet
vraigam1=vgam1     ; rho1= -1 ;   X1= (-log(runif(n)))^(-vraigam1)                 
}
if (nom1=="Student"){ 
# Student
vraigam1=vgam1     ; rho1=-2*vgam1 ;   X1=rt(n,1/vraigam1)   # gamma = 1/nu, rho = -2/nu ?  
#X1=X1[X1>0]             
#X1=abs(X1) # a bannir ?  car les grandes valeurs n�gatives deviennent grandes valeurs positives
#X1=X1-min(X1)+0.1
}

# Choix de la seconde loi (celle de X2) 

if (nom2=="Burr"){ 
# Burr
gamma2=vgam2 ; rho2=vrho2  ;  thet2=1 ;  tau2=-rho2/gamma2; lam2=-1/rho2    ;  X2=(thet2*(1-runif(m))^(-1/lam2)-thet2)^(1/tau2)    
}
if (nom2=="Fr�chet"){ 
# Frechet
vraigam2=vgam2 ;  ; rho2= -1 ; X2=(-log(runif(m)))^(-vraigam2) 
}
if (nom2=="Student"){ 
# Student
vraigam2=vgam2     ; rho2=-2*vgam2 ;   X2= rt(m,1/vraigam2)   # gamma = 1/nu, rho = -2/nu ?               
#X2=X2[X2>0]             
#X2=abs(X2)  # a bannir ?  car les grandes valeurs n�gatives deviennent grandes valeurs positives
#X2=X2-min(X2)+0.1
}

# Choix de la troisi�me loi (celle de X3) 

if (nom3=="Burr"){ 
# Burr
gamma3=vgam3 ; rho3=vrho3  ;  thet3=1 ;  tau3=-rho3/gamma3; lam3=-1/rho3    ;  X3=(thet3*(1-runif(o))^(-1/lam3)-thet3)^(1/tau3)    
}
if (nom3=="Fr�chet"){ 
# Frechet
vraigam3=vgam3 ;  ; rho3= -1 ; X3=(-log(runif(o)))^(-vraigam3) 
}
if (nom3=="Student"){ 
# Student
vraigam3=vgam3     ; rho3=-2*vgam3 ;   X3= rt(o,1/vraigam3)   # gamma = 1/nu, rho = -2/nu ?               
#X3=X3[X3>0]             
#X3=abs(X3)  # a bannir ?  car les grandes valeurs n�gatives deviennent grandes valeurs positives
#X3=X3-min(X3)+0.1
}

X1=sort(X1) 
X2=sort(X2)
X3=sort(X3)

# choix des k pour estimer rho1,rho2,rho3 , varie suivant que l'echantillon est Student ou non
# (en effet, pour des echantillons de Student, les valeurs possiblement <0 peuvent gener l'estimation de rho)
# (dans ce cas on limite la valeur de k choisie pour l'estimation de rho, � une valeur rendant impossible l'utilisation de valeurs n�gatives)

nbneg1=sum(X1<0); nbneg2=sum(X2<0); nbneg3=sum(X3<0)
if (nom1=="Student")
 {valkrho1=round(min(n-nbneg1-1,2*n^(0.995)/log(log(n)))) }  
 else {valkrho1=round(min(n-1,2*n^(0.995)/log(log(n))))}   
if (nom2=="Student")
 {valkrho2=round(min(m-nbneg2-1,2*m^(0.995)/log(log(m)))) }  
 else {valkrho2=round(min(m-1,2*m^(0.995)/log(log(m))))}
if (nom3=="Student")
 {valkrho3=round(min(o-nbneg3-1,2*o^(0.995)/log(log(o)))) }  
 else {valkrho3=round(min(o-1,2*o^(0.995)/log(log(o))))}

# estimation de rho1,rho2,rho3  pour le calcul de k1,k2,k3 optimaux propos�s par Hall et Welch (1985) 

  Xk1=X1[n-valkrho1]   ; Xk2=X2[m-valkrho2]   ; Xk3=X3[o-valkrho3]
  X1pos=X1[X1>0]       ; X2pos=X2[X2>0]       ; X3pos=X3[X3>0]

  M1X1k1=(1/valkrho1)*sum(log(X1pos/Xk1)*(X1pos>Xk1)) ;  M1X2k2=(1/valkrho2)*sum(log(X2pos/Xk2)*(X2pos>Xk2)) ;  M1X3k3=(1/valkrho3)*sum(log(X3pos/Xk3)*(X3pos>Xk3))
  M2X1k1 = (1/valkrho1)*sum((log(X1pos/Xk1))^2*(X1pos>Xk1))  ; M2X2k2 = (1/valkrho2)*sum((log(X2pos/Xk2))^2*(X2pos>Xk2))  ; M2X3k3 = (1/valkrho3)*sum((log(X3pos/Xk3))^2*(X3pos>Xk3))
  M3X1k1 = (1/valkrho1)*sum((log(X1pos/Xk1))^3*(X1pos>Xk1))  ; M3X2k2 = (1/valkrho2)*sum((log(X2pos/Xk2))^3*(X2pos>Xk2))  ; M3X3k3 = (1/valkrho3)*sum((log(X3pos/Xk3))^3*(X3pos>Xk3))

  if (rho1 < -1)  { T1=(M1X1k1-(M2X1k1/2)^(1/2)) / ((M2X1k1/2)^(1/2)-(M3X1k1/6)^(1/3))  }  else  { T1=(log(M1X1k1)-(log(M2X1k1/2))/2)/((log(M2X1k1/2))/2-(log(M3X1k1/6))/3) }

  chaprho1 = -abs(3*(T1-1)/(T1-3))

  if (rho2 < -1)  { T2=(M1X2k2-(M2X2k2/2)^(1/2)) / ((M2X2k2/2)^(1/2)-(M3X2k2/6)^(1/3))  }  else  { T2=(log(M1X2k2)-(log(M2X2k2/2))/2)/((log(M2X2k2/2))/2-(log(M3X2k2/6))/3) }

  chaprho2 = -abs(3*(T2-1)/(T2-3))

  if (rho3 < -1)  { T3=(M1X3k3-(M2X3k3/2)^(1/2)) / ((M2X3k3/2)^(1/2)-(M3X3k3/6)^(1/3))  }  else  { T3=(log(M1X3k3)-(log(M2X3k3/2))/2)/((log(M2X3k3/2))/2-(log(M3X3k3/6))/3) }

  chaprho3 = -abs(3*(T3-1)/(T3-3))


# calcul des k optimaux pour X1,X2,X3

  koptX1 = min( n-nbneg1-1 , round(n^(-2*chaprho1/(1-2* chaprho1))) )
  koptX2 = min( m-nbneg2-1 , round(m^(-2*chaprho2/(1-2* chaprho2))) )
  koptX3 = min( o-nbneg3-1 , round(o^(-2*chaprho3/(1-2* chaprho3))) )
  #koptX3 = 50
  # (on veille encore � ne pas prendre de valeur de k qui fasse consid�rer des valeurs n�gatives de X, pour le cas Student) 
  #koptX1=n^(2/3)   # valeur arbitraire de koptX1 prise par la formule de Hall & Welsh, comme si rhochap1 valait -1
  #koptX2=m^(2/3)   # valeur arbitraire de koptX2 prise par la formule de Hall & Welsh, comme si rhochap2 valait -1
  #koptX3=o^(2/3)   # valeur arbitraire de koptX3 prise par la formule de Hall & Welsh, comme si rhochap3 valait -1
    		    
# Calcul des seuils optimaux  

  X1opt=X1[n-koptX1]
  X2opt=X2[m-koptX2]
  X3opt=X3[o-koptX3]

# Estimateurs de Hill sur �chantillons de taille m et n en kopt

  Hill1opt = mean(log(X1[(n-koptX1+1):n]/X1opt))  # �chantillon X1
  Hill2opt = mean(log(X2[(m-koptX2+1):m]/X2opt))  # �chantillon X2 
  Hill3opt = mean(log(X3[(o-koptX3+1):o]/X3opt))  # �chantillon X3 
  
     
# Calculs des log spacings 

  Y1 =  (1:koptX1) * log ( X1[n:(n-koptX1+1)] / X1[(n-1):(n-koptX1)]) 
  Y2 =  (1:koptX2) * log ( X2[m:(m-koptX2+1)] / X2[(m-1):(m-koptX2)])  
  Y3 =  (1:koptX3) * log ( X3[o:(o-koptX3+1)] / X3[(o-1):(o-koptX3)])  

  # calcul des Sn2

  Sn1= mean((Y1-Hill1opt)^2)
  Sm2= mean((Y2-Hill2opt)^2)
  So3= mean((Y3-Hill3opt)^2)

  # calcul de muchap

  muchap[i] = (koptX1 * Hill1opt / Sn1 + koptX2 * Hill2opt / Sm2 + koptX3 * Hill3opt / So3 ) / (koptX1 / Sn1 + koptX2 / Sm2 + koptX3 / So3 )

  # Calcul de la statistique de test Q(muchap)

  Qmuchap[i] = koptX1 *(Hill1opt-muchap[i])^2 / Sn1 + koptX2 *(Hill2opt- muchap[i])^2 / Sm2 + koptX3 *(Hill3opt- muchap[i])^2 / So3
  nb= nb+ (Qmuchap[i] > chideux1)

k1optimal[i] = koptX1
k2optimal[i] = koptX2
k3optimal[i] = koptX3

valkrhoopt1[i]=valkrho1
valkrhoopt2[i]=valkrho2
valkrhoopt3[i]=valkrho3
vecnbneg1[i]=nbneg1
vecchaprho1[i]=chaprho1
vecchaprho2[i]=chaprho2
vecchaprho3[i]=chaprho3
vecHill1opt[i]=Hill1opt
vecHill2opt[i]=Hill2opt
vecHill3opt[i]=Hill3opt 

} # fin for i=1: N  


# Evaluation de l'erreur de premi�re esp�ce (dans le cas o� H0 est vraie)

puissance = 100 * nb/N

if (affichagedetaille=="oui") 
{
cat("Premi�re  Loi ",nom1,"(",vgam1,", rho=",vrho1,") , n=",n," \n")
cat("Seconde   Loi ",nom2,"(",vgam2,", rho=",vrho2,") , m=",m," \n")
cat("Troisi�me Loi ",nom3,"(",vgam3,", rho=",vrho3,") , o=",o,", nb simuls=",N,"\n")
#cat("R�partition des nombres de valeurs n�gatives dans X1 : \n")
#print(summary(vecnbneg1))
cat("Valeurs optimales de k1rho trouv�es (M,Q1,Q3) :",round(median(valkrhoopt1),3),round(quantile(valkrhoopt1,0.25),3),round(quantile(valkrhoopt1,0.75),3)," \n")
cat("Valeurs optimales de k2rho trouv�es (M,Q1,Q3) :",round(median(valkrhoopt2),3),round(quantile(valkrhoopt2,0.25),3),round(quantile(valkrhoopt2,0.75),3)," \n")
cat("Valeurs optimales de k3rho trouv�es (M,Q1,Q3) :",round(median(valkrhoopt3),3),round(quantile(valkrhoopt3,0.25),3),round(quantile(valkrhoopt3,0.75),3)," \n")
cat("Valeurs des estimations de rho1=",vrho1," trouv�es (M,Q1,Q3) :",round(median(vecchaprho1),3),round(quantile(vecchaprho1,0.25),3),round(quantile(vecchaprho1,0.75),3)," \n")
cat("Valeurs des estimations de rho2=",vrho2," trouv�es (M,Q1,Q3) :",round(median(vecchaprho2),3),round(quantile(vecchaprho2,0.25),3),round(quantile(vecchaprho2,0.75),3)," \n")
cat("Valeurs des estimations de rho3=",vrho3," trouv�es (M,Q1,Q3) :",round(median(vecchaprho3),3),round(quantile(vecchaprho3,0.25),3),round(quantile(vecchaprho3,0.75),3)," \n")
cat("Valeurs optimales de k1 trouv�es (M,Q1,Q3) :",round(median(k1optimal),3),round(quantile(k1optimal,0.25),3),round(quantile(k1optimal,0.75),3)," \n")
cat("Valeurs optimales de k2 trouv�es (M,Q1,Q3) :",round(median(k2optimal),3),round(quantile(k2optimal,0.25),3),round(quantile(k2optimal,0.75),3)," \n")
cat("Valeurs optimales de k3 trouv�es (M,Q1,Q3) :",round(median(k3optimal),3),round(quantile(k3optimal,0.25),3),round(quantile(k3optimal,0.75),3)," \n")
cat("Valeurs des estimations de gamma1=",vgam1," trouv�es (M,Q1,Q3) :",round(median(vecHill1opt),3),round(quantile(vecHill1opt,0.25),3),round(quantile(vecHill1opt,0.75),3)," \n")
cat("Valeurs des estimations de gamma2=",vgam2," trouv�es (M,Q1,Q3) :",round(median(vecHill2opt),3),round(quantile(vecHill2opt,0.25),3),round(quantile(vecHill2opt,0.75),3)," \n")
cat("Valeurs des estimations de gamma3=",vgam3," trouv�es (M,Q1,Q3) :",round(median(vecHill3opt),3),round(quantile(vecHill3opt,0.25),3),round(quantile(vecHill3opt,0.75),3)," \n")
cat("Evaluation de la puissance/du niveau de la proc�dure pour alpha =",100*alpha,"% : ",puissance , "\n\n")
}