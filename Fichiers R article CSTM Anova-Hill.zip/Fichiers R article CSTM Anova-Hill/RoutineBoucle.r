# Fichier permettant de faire tourner en boucle pour une grille de valeurs de k1 et k2 notre test de comparaison
# "en boucle" signifiant pour une s�rie de couples de lois donn�e .
#
# Le programme fait alors apparaitre les graphiques "contour" correspondant aux simuls (un par couple de lois donn�)

# Simulations de niveau : celles de Mougeot & Tribouley (sauf mod�le de Pareto-Hall)

noms1=c("Student","Student","Student", "Fr�chet","Fr�chet","Fr�chet", "Burr","Burr","Burr", "Student","Student", "Student","Student","Student", "Fr�chet","Fr�chet","Fr�chet","Fr�chet","Fr�chet","Fr�chet")
noms2=c("Student","Student","Student", "Fr�chet","Fr�chet","Fr�chet", "Burr","Burr","Burr", "Fr�chet","Fr�chet", "Burr","Burr","Burr",          "Burr","Burr","Burr","Burr","Burr","Burr")
vgam1s=c(1/4,1/2,1, 1/4,1/2,1, 1/4,1/4,1/2, 1/2,1,  1/2,1,1,   1/4,1/2,1,1/4,1/2,1)
vgam2s=c(1/4,1/2,1, 1/4,1/2,1, 1/4,1/4,1/2, 1/2,1,  1/2,1,1,   1/4,1/2,1,1/4,1/2,1)
vrho1s=c(-1/2,-1,-2, -1,-1,-1,  -2,-1,-1,    -1,-2, -1,-2,-2,   -1,-1,-1,-1,-1,-1)
vrho2s=c(-1/2,-1,-2, -1,-1,-1,  -2,-2,-1,    -1,-1, -1/2,-1,-2, -1,-1,-1,-2,-2,-2)
numeroducas = 1

# Simulation de niveaux pour un seul couple 

noms1=c("Burr")
noms2=c("Burr")
vgam1s=c(1/4)
vgam2s=c(1/4)
vrho1s=c(-2)
vrho2s=c(-2)
numeroducas = 1

# Simulation de niveaux (ceux repr�sent�s dans l'article)

noms1=c("Burr","Burr","Fr�chet","Fr�chet")
noms2=c("Burr","Burr","Burr","Burr")
vgam1s=c(1/4,1/4,1/2,1/2)
vgam2s=c(1/4,1/4,1/2,1/2)
vrho1s=c(-2,-1,-1,-1)
vrho2s=c(-2,-2,-1,-2)
numeroducas = 1


par(mfrow=c(2,2))

while (numeroducas <= length(noms1)) {

nom1=noms1[numeroducas] ; nom2=noms2[numeroducas]
vgam1=vgam1s[numeroducas] ; vgam2=vgam2s[numeroducas]
vrho1=vrho1s[numeroducas] ; vrho2=vrho2s[numeroducas]

if (nom1=="Student") {
grillek1 = seq(10,200,by=10) ; lgk1 = length(grillek1)
} else {
grillek1 = seq(10,300,by=10) ; lgk1 = length(grillek1)
}
if (nom2=="Student") {
grillek2 = seq(10,200,by=10) ; lgk2 = length(grillek2)
} else {
grillek2 = seq(10,300,by=10) ; lgk2 = length(grillek2)
}
grillepuissance = matrix(rep(0,lgk1*lgk2),lgk1,lgk2)

for (i1 in 1:lgk1) {
 for (i2 in 1:lgk2) {
  vk1 = grillek1[i1] ; vk2 = grillek2[i2]
  source("F:\\Recherche\\Extr�mes\\ArtAnovaHill\\TestComparaisonDeuxGammasPositifsOptimal.R")
  grillepuissance[i1,i2] = puissance
  }
 }

cat("Premi�re loi ",nom1,"(",vgam1,", rho=",vrho1,"),  Seconde Loi ",nom2,"(",vgam2,", rho=",vrho1,"), n=",n,", m=",m,", nb simuls=",N,"\n")
cat("Valeurs de k1 :",grillek1,"\n")
cat("Valeurs de k2 :",grillek2,"\n")
cat("Puissance : \n") ; print(grillepuissance)

titre = paste(nom1,'(',vgam1,') vs ',nom2,'(',vgam2,'), n=',n,', m=',m,', N=',N,  sep='')

if (vgam1==0.5) {vgam1='1demi'}; if (vgam1==0.25) {vgam1='1quart'}
if (vgam2==0.5) {vgam2='1demi'}; if (vgam2==0.25) {vgam2='1quart'}
nomfic=paste('GraphiquesNiveau\\',nom1,vgam1,'rho',vrho1,nom2,vgam2,'rho',vrho2,'n',n,'m',m,'N',N,'Gris.jpg',sep='')
jpeg(nomfic,quality=100,width=600,height=600)
filled.contour(grillek1,grillek2,grillepuissance,plot.title = titre, xlab = "k1", ylab = "k2",levels=c(3,4.5,5.5,7),col=grey(c(0.3,0.5,0.75)) )
dev.off()

numeroducas = numeroducas + 1

} # fin du while


