##########################################################
####### el.test(), from Owen, Modified by Mai Zhou #######
##########################################################

#### [[ Assorti de commentaires supplementaires de ma part ]]

# Cette fonction permet de calculer EL(theta) (ou plutot -2log ELR(theta))
# pour le cadre theta=mu= la moyenne d'un echantillon de taille p), et
# ainsi de calculer la p-valeur de la statistique de test de l'hypothese
# H_0 : "la vraie valeur de la moyenne est cette valeur mu".
#
# Cela implique de resoudre l'equation en lambda permettant de calculer
# la valeur optimale lambda(theta). Cela va se faire par un algorithme
# d'optimisation avec etapes Newton + gradient.
#
# La generalisation a une autre fonction g(theta,y) ne semble pas poser
# de probleme, car les bonnes proprietes mathematiques qui font tout
# fonctionner (du cote de l'optimisation) ne dependent pas de la fonction g.

el.test <- function( x, mu, lam, maxit=25, gradtol=1e-7, 
                        svdtol = 1e-9, itertrace=FALSE ){
x <- as.matrix(x)
n <- nrow(x)
p <- ncol(x)
mu <- as.vector(mu)
if( length(mu) !=p )
  stop("mu must have same dimension as observation vectors.")
if( n <= p )
  stop("Need more observations than length(mu) in el.test().")

z <- t( t(x) -mu )

# z est la matrice nxp des donnees "centrees" (en mu, et non en \bar X_n)

#
#    Scale the problem, by a measure of the size of a 
# typical observation.  Add a tiny quantity to protect
# against dividing by zero in scaling.  Since z*lam is
# dimensionless, lam must be scaled inversely to z.
#
# Je ne comprends pas pourquoi ce changement d'echelle,
# puisqu'au final on neutralise scale dans lam.

TINY <- sqrt( .Machine$double.xmin )
scale <- mean( abs(z) ) + TINY
z <- z/scale

if( !missing(lam) ){
  lam <- as.vector(lam)
  lam <- lam*scale
  if( logelr(z,rep(0,p),lam)>0 )lam <- rep(0,p)
}
if(  missing(lam)  )
  lam <- rep(0,p)

# Tres important : le log de l'ELR est cense etre negatif.
# Ici, lambda vaut lam, et non la valeur correcte de lambda,
# donc rien ne garantit que les probas p_i(lam) soient de 
# produit < 1. Cependant il n'y a visiblement pas de verification
# de la positivite de toutes les coordonnees de arg = 1 + z * lam (A VOIR)
#
# Quoi qu'il en soit, si la valeur initiale lam de lambda est 
# "mal choisie", alors on la reinitialise a lam=0. 


# Take some precaution against users specifying
# tolerances too small.

if( svdtol < TINY )svdtol <- TINY
if( gradtol < TINY )gradtol <- TINY

#    Preset the weights for combining Newton and gradient
# steps at each of 16 inner iterations, starting with
# the Newton step and progressing towards shorter vectors
# in the gradient direction.  Most commonly only the Newton
# step is actually taken, though occasional step reductions
# do occur.

# Il va y avoir mise en oeuvre d'un algorithme de type Descente,
# avec des iterations internes : cad, pour la valeur courante lambda_n de
# lambda, on va calculer le gradient en lambda_n et la hessienne en lambda_n
# (et le produit "inverse de la Hessienne fois le gradient")
# puis utiliser ces informations pour tester differentes valeurs possibles
# de lambda_{n+1} obtenue a partir de lambda_n et de differentes ponderations
# de la "Newton Step" et de la "Gradient Step". Ce qui suit, ce sont les
# expressions de ces ponderations (nwts=Newton weights, gwts=Gradient weights)

nwts <- c( 3^-c(0:3), rep(0,12) )
gwts <- 2^( -c(0:(length(nwts)-1)))
gwts <- (gwts^2 - nwts^2)^.5
gwts[12:16] <- gwts[12:16] * 10^-c(1:5)

#    Iterate, finding the Newton and gradient steps, and
# choosing a step that reduces the objective if possible.

# On calcule maintenant ce qu'il appelle les "Newton step" et "Gradient Step",
# ce qui implique de calculer le gradient en lam, et l'inverse de la Hessienne en lam.

nits <- 0
gsize <- gradtol + 1
# nits est le numero de l'iteration courante; gsize est une mesure de 
# la petitesse de la norme du gradient : quand elle sera trop petite, 
# on sortira de l'algo, estimant qu'on a minimise la fonction cible.
# On sortira aussi de l'algo (boucle while) quand on aura depasse le
# nombre autorise (maxit) d'iterations (25 par defaut).

while(  nits<maxit && gsize > gradtol  ){
  arg  <- 1 + z %*% lam
  wts1 <- as.vector( llogp(arg, 1/n) )
  wts2 <- as.vector( -llogpp(arg, 1/n) )^.5
  grad <- as.matrix( -z*wts1 )
  #############grad <- as.vector( apply( grad, 2, sum ) )
  grad <- as.vector(rowsum(grad, rep(1, nrow(grad)) ) )
  gsize <- mean( abs(grad) )
  hess <- z*wts2

# arg est le vecteur de coordonnees les 1 + <lam , x_i-mu>
# wts1 est le vecteur de coordonnees les (1 + <lam , x_i-mu>)^(-1)
# wts2 est le vecteur de coordonnees les abs( (1 + <lam , x_i-mu>)^(-1) )
# donc en gros, quand lam n'est pas trop grand, wts2 vaut wts1.
# grad est la somme des lignes de la matrice -z*wts1, dont les lignes
# sont les     u_i = (1 + <lam , x_i-mu>)^(-1) (x_i-mu). 
# hess n'est pas la Hessienne, c'est (aux vals abs pres) l'oppose de la 
# matrice que je viens d'evoquer. 
#                                 -1
#  The Newton step is -(hess'hess)    grad,
#  where the matrix hess is a sqrt of the Hessian.
#  Use svd on hess to get a stable solution.

# Il va falloir inverser la Hessienne, qui vaut  hess'.hess (vient de la
# situation presente, ou Hess(lam)=sum_{i=1}^n u_i^t u_i, et du fait
# que hess est de lignes les u_i donc hess'.hess vaut bien Hess(lam) ).
# 
# Pour inverser Hess, il va donc y avoir recours a la decomposition en
# valeurs singulieres de la matrice rectangulaire hess n*p.
# Toutefois, on se demande si, pour p petit, il est bien raisonnable
# de sortir la grosse artillerie pour inverser Hess !! (p=2, Hess matrice 2x2 !)

## Voir code original de el.test.R pour suggestions d'alternatives a svd() (La.svd())

  svdh <- svd( hess )
  if( min(svdh$d) < max(svdh$d)*svdtol )
    svdh$d <- svdh$d + max(svdh$d)*svdtol
  # Verification dite "condition number" 
  # (ratio lambda_max/lambda_min = symptome de stabilite du systeme)
  nstep <- svdh$v %*% (t(svdh$u)/svdh$d)
  # si hess = UDV^t, ou D est la matrice diagonale de coefficients
  # les racines carrees des vps (>0) de Hess_f(lam), tUU=I, tVV=I,
  # alors nstep est la matrice N = V.inv(D).Ut, donc telle que hess.N = I
  # A ce stade, nstep est de taille pxn (car V pxp, U nxp, D pxp)
  # A l'etape suivante, nstep devient un vecteur px1 
  nstep <- as.vector( nstep %*% matrix(wts1/wts2,n,1) )
  # On a alors -H^(-1)grad = nstep (voir notes annexes pour 1 justif) 

  # Maintenant calcul de la "Gradient step" (environ egale a -grad ?)  

  gstep <- -grad
  if(  sum(nstep^2) < sum(gstep^2) )
    gstep <- gstep*(sum(nstep^2)^.5/sum(gstep^2)^.5)

  ologelr <- -sum( llog(arg,1/n) )
  # On calcule la valeur actuelle de "-log ELR"(lambda) : on va la
  # comparer a celle obtenue a partir de la valeur actualisee de lambda
  # (on veut qu'a chaque etape on diminue un peu cette valeur)

  ninner <- 0 
  # ninner est le nombre courant d'iterations internes a l'iteration courante
  for(  i in 1:length(nwts) ){
    nlogelr <- logelr( z,rep(0,p),lam+nwts[i]*nstep+gwts[i]*gstep )
    #
    # on evalue la fonction "-log ELR" en une nouvelle valeur de lambda
    # (Rem : ologelr= old log ELR, nlogelr= new log ELR)
    #
    if( nlogelr < ologelr ){
      lam <- lam+nwts[i]*nstep+gwts[i]*gstep
      ninner <- i
      break
      # si cela mene a une diminution de la valeur de "-log ELR", alors on achete
      # et on sort de cette boucle interne for; sinon on teste une nouvelle valeur
      # qui soit moins loin (mais dans la mÍme "direction") que la precedente 
      # (en effet, les poids nwts et gwts sont decroissants : les plus gros pour i petit)
    }
  }
  nits <- nits+1
  if(  ninner==0  )nits <- maxit
  # On sort de la procedure si aucune des propositions d'actualisation de lambda
  # (boucle interne ci-dessus) n'a mene a une diminution de la fonction cible
  if( itertrace )
    print( c(lam, nlogelr, gsize, ninner) )
  # On affiche qqs details a chaque iteration si cela a ete demande au lancement de la proc.
}

list( "-2LLR" = -2*nlogelr, Pval = 1-pchisq(-2*nlogelr, df=p),
     lambda = lam/scale, grad=grad*scale, z=z*scale,
 hess=t(hess)%*%hess*scale^2, wts=wts1, nits=nits )
}

logelr <- function( x, mu, lam ){ 
x <- as.matrix(x)
n <- nrow(x)
p <- ncol(x)
if(  n <= p  )
  stop("Need more observations than variables in logelr.")
mu <- as.vector(mu)
if(  length(mu) != p  )
  stop("Length of mean doesn't match number of variables in logelr.")

z <- t( t(x) -mu )
arg <- 1 + z %*% lam
return( - sum( llog(arg,1/n) ) ) 
#return( -sum( log(arg) ) )
}

#
#    The function llog() is equal to the natural
#  logarithm on the interval from eps >0 to infinity.
#  Between -infinity and eps, llog() is a quadratic.
#  llogp() and llogpp() are the first two derivatives
#  of llog().  All three functions are continuous
#  across the "knot" at eps.
#
#    A variation with a second knot at a large value
#  M did not appear to work as well.
#
#    The cutoff point, eps, is usually 1/n, where n
#  is the number of observations.  Unless n is extraordinarily
#  large, dividing by eps is not expected to cause numerical
#  difficulty.
#

llog <- function( z, eps ){

ans <- z
lo <- (z<eps)
ans[ lo  ] <- log(eps) - 1.5 + 2*z[lo]/eps - 0.5*(z[lo]/eps)^2
ans[ !lo ] <- log( z[!lo] )
ans
}

llogp <- function( z, eps ){

ans <- z
lo <- (z<eps)
ans[ lo  ] <- 2.0/eps - z[lo]/eps^2
ans[ !lo ] <- 1/z[!lo]
ans
}

llogpp <- function( z, eps ){

ans <- z
lo <- (z<eps)
ans[ lo  ] <- -1.0/eps^2
ans[ !lo ] <- -1.0/z[!lo]^2
ans
}