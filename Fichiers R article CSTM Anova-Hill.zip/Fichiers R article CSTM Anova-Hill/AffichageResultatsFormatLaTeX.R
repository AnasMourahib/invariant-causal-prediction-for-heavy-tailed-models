# Ce fichier a pour but de faire �crire automatiquement les r�sultats des
#   simulations sous format "table LaTeX" ; je n'ai pas encore r�ussi � r�soudre
#   le probl�me de l'affichage de 2 chiffres apr�s la virgule, ni celui de
#   l'�criture via cat du symbole antislash (\), car celui-ci a une autre
#   signification sous R (fortran ?).
#
# Il faut au pr�alable avoir lanc� le code "RoutineBoucleHallWelch.R", et c'est tout !

if (version=="Niveau") 
{
 cat("\n Distr. & gamma_1=gamma_2 & rho_1 & rho_2 & WW & & MT & \n")
 for (i in 1:length(noms1)) {
  cat(noms[i]," & ",vgam1s[i]," & ",vrho1s[i]," & ",vrho2s[i]," & ",vecpuissance5[i]," & ",vecpuissance10[i]," & ",valMT5[i]," & ",valMT10[i]," \n")
  }
}
if (version=="Puissance")
{
 cat("\n Distr. & gamma_1 & gamma_2 & rho_1 & rho_2 & WW & & MT & \n")
 for (i in 1:length(noms1)) {
  cat(noms[i]," & ",vgam1s[i]," & ",vgam2s[i]," & ",vrho1s[i]," & ",vrho2s[i]," & ",vecpuissance5[i]," & ",vecpuissance10[i]," & ",valMT5[i]," & ",valMT10[i]," \n")
  }
}
