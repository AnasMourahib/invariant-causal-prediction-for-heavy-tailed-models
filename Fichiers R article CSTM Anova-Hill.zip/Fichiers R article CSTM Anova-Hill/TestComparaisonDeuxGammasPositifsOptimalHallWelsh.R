# Version  28 juin 2013 (pr�c�dente, 8 juin 2012)
#  Test de comparaison de deux Gamma Positifs � l'aide de l'ANOVA appliqu�e � l'estimateur de Hill 
#  Le but est en particulier de comparer nos r�sultats avec ceux de Mathilde Mougeot & Karine Tribouley (2010) 
#  (cela se fait avec le code "RoutineBoucleHallWelch.R")
#
#  M�thode de choix des k optimaux : celle propos�e par Hall and Welsh (1985) 
#
# En entr�e : n, le nb de simuls N, les noms des 2 lois compar�es, les valeurs vgam1,vgam2,vrho1,vrho2
# En sortie : pour chaque simul, 
#   - la valeur de la statq Qmuchap
#   - la proportion (en pourcentage) des valeurs de Qmuchap qui d�passe le quantile d'ordre 5% du chi2(1) 
#           (c'est dans la variable puissance, m�me s'il s'agit parfois plut�t d'un niveau/risque estim�)
#   - les valeurs "optimales" de k1 et k2 qui auront �t� �valu�es via Hall & Welsh
#   - les valeurs de gammachapeau1 et gammachapeau2 (estim. de Hill)
#   - les valeurs de k1rho et k2rho choisies pour estimer rho1 et rho2
#   - le nombre de valeurs n�gatives dans l'�chantillon 1 (car celui-ci est parfois de loi de Student,
#         donc il faut faire attention aux observations n�gatives pour qu'elles n'entrent pas dans le
#         calcul de l'estimation de rho1 (logarithmes d'observations). 
#   
#
# Noter qu'on utilise le calcul de Q(muchap), et non pas celui de l(gammachap) (qui est plus long, utilise el.test)
# Cependant le code le permet en d�cochant quelques di�ses aux bons endroits.

# source("/Users/rworms/Rech/TestTailIndex/simulations/el.testAnnote.R")   
# source("C:/Users/Julien/Roulio/Recherche/Extr�mes/ArtAnovaHill/el.testAnnote.R")  

library(evd)

N=2000 
n=800  
m =700  

valkrho1=round(min(n-1,2*n^(0.995)/log(log(n))))   
valkrho2=round(min(m-1,2*m^(0.995)/log(log(m))))   # choix des k pour estimer rho1 et rho 2  

nb=0  # valeur initiale 
muchap = rep(0,N) # contient les valeurs de muchap
lmuchap = rep(0,N) # contient les valeurs de l(muchap,muchap)
Qmuchap = rep(0,N) # contient les valeurs de Q(muchap,muchap)

valkrhoopt1=rep(0,N)
valkrhoopt2=rep(0,N)
vecnbneg1=rep(0,N)
vecchaprho1=rep(0,N)
vecchaprho2=rep(0,N)
vecHill1opt=rep(0,N)
vecHill2opt=rep(0,N)

alpha=0.05 ; chideux1=qchisq(1-alpha,1) 

for (i in  1:N) {    # on simule N n-echantillons
  
# Choix de la premiere loi (celle de X1) 

if (nom1=="Burr"){ 
# Burr
gamma1=vgam1 ; rho1=vrho1  ;  thet1=1 ;  tau1=-rho1/gamma1; lam1=-1/rho1    ;  X1=(thet1*(1-runif(n))^(-1/lam1)-thet1)^(1/tau1)   
}
if (nom1=="Fr�chet"){                         
# Frechet
vraigam1=vgam1     ; rho1= -1 ;   X1= (-log(runif(n)))^(-vraigam1)                 
}
if (nom1=="Student"){ 
# Student
vraigam1=vgam1     ; rho1=-2*vgam1 ;   X1=rt(n,1/vraigam1)   # gamma = 1/nu, rho = -2/nu ?  
#X1=abs(X1) # a bannir ?  car les grandes valeurs n�gatives deviennent grandes valeurs positives
#X1=X1[X1>0]             
#X1=X1-min(X1)+0.1
}

# Choix de la seconde loi (celle de X2) 

if (nom2=="Burr"){ 
# Burr
gamma2=vgam2 ; rho2=vrho2  ;  thet2=1 ;  tau2=-rho2/gamma2; lam2=-1/rho2    ;  X2=(thet2*(1-runif(m))^(-1/lam2)-thet2)^(1/tau2)    
}
if (nom2=="Fr�chet"){ 
# Frechet
vraigam2=vgam2 ;  ; rho2= -1 ; X2=(-log(runif(m)))^(-vraigam2) 
}
if (nom2=="Student"){ 
# Student
vraigam2=vgam2     ; rho2=-2*vgam2 ;   X2= rt(m,1/vraigam2)   # gamma = 1/nu, rho = -2/nu ?               
#X2=abs(X2)  # a bannir ?  car les grandes valeurs n�gatives deviennent grandes valeurs positives
#X2=X2[X2>0]             
#X2=X2-min(X2)+0.1
}

X1=sort(X1) 
X2=sort(X2)


# choix des k pour estimer rho1 et rho 2 , varie suivant que l'echantillon est Student ou non
# (en effet, pour des echantillons de Student, les valeurs possiblement <0 peuvent faire capoter l'estimation de rho)
# (dans ce cas on limite la valeur de k choisie pour l'estimation de rho, � une valeur rendant impossible l'utilisation de valeurs n�gatives)

nbneg1=sum(X1<0); nbneg2=sum(X2<0)
if (nom1=="Student")
 {valkrho1=round(min(n-nbneg1-1,2*n^(0.995)/log(log(n)))) }  
 else {valkrho1=round(min(n-1,2*n^(0.995)/log(log(n))))}   
if (nom2=="Student")
 {valkrho2=round(min(m-nbneg2-1,2*m^(0.995)/log(log(m)))) }  
 else {valkrho2=round(min(m-1,2*m^(0.995)/log(log(m))))}


# estimation de rho 1 et rho 2  pour le calcul de k1 et k2 optimaux propos�s par Hall et Welch (1985) 

  Xk1=X1[n-valkrho1]   ; Xk2=X2[m-valkrho2]
  X1pos=X1[X1>0]       ; X2pos=X2[X2>0]

  M1X1k1=(1/valkrho1)*sum(log(X1pos/Xk1)*(X1pos>Xk1)) ;  M1X2k2=(1/valkrho2)*sum(log(X2pos/Xk2)*(X2pos>Xk2))
  M2X1k1 = (1/valkrho1)*sum((log(X1pos/Xk1))^2*(X1pos>Xk1))  ; M2X2k2 = (1/valkrho2)*sum((log(X2pos/Xk2))^2*(X2pos>Xk2))
  M3X1k1 = (1/valkrho1)*sum((log(X1pos/Xk1))^3*(X1pos>Xk1))  ; M3X2k2 = (1/valkrho2)*sum((log(X2pos/Xk2))^3*(X2pos>Xk2))

  if (rho1 < -1)  { T1=(M1X1k1-(M2X1k1/2)^(1/2)) / ((M2X1k1/2)^(1/2)-(M3X1k1/6)^(1/3))  }  else  { T1=(log(M1X1k1)-(log(M2X1k1/2))/2)/((log(M2X1k1/2))/2-(log(M3X1k1/6))/3) }

  chaprho1 = -abs(3*(T1-1)/(T1-3))

  if (rho2 < -1)  { T2=(M1X2k2-(M2X2k2/2)^(1/2)) / ((M2X2k2/2)^(1/2)-(M3X2k2/6)^(1/3))  }  else  { T2=(log(M1X2k2)-(log(M2X2k2/2))/2)/((log(M2X2k2/2))/2-(log(M3X2k2/6))/3) }

  chaprho2 = -abs(3*(T2-1)/(T2-3))


# calcul des k optimaux pour X1 et pour X2

  koptX1 = min( n-nbneg1-1 , round(n^(-2*chaprho1/(1-2* chaprho1))) )
  koptX2 = min( m-nbneg2-1 , round(m^(-2*chaprho2/(1-2* chaprho2))) )
  # (on veille encore � ne pas prendre de valeur de k qui fasse consid�rer des valeurs n�gatives de X, pour le cas Student) 
  #koptX1=55   # valeur arbitraire de koptX1 prise pour n=800 pour r�parer le probl�me ds le cas Student
  #koptX2=50   # valeur arbitraire de koptX prise pour n=700 pour r�parer le probl�me ds le cas Student
  #koptX1=n^(2/3)   # valeur arbitraire de koptX1 prise par la formule de Hall & Welsh, comme si rhochap1 valait -1
  #koptX2=m^(2/3)   # valeur arbitraire de koptX2 prise par la formule de Hall & Welsh, comme si rhochap2 valait -1
    		    
# Calcul des seuils optimaux  

  X1opt=X1[n-koptX1]
  X2opt=X2[m-koptX2]

# Estimateurs de Hill sur �chantillons de taille m et n en kopt

  Hill1opt = mean(log(X1[(n-koptX1+1):n]/X1opt))  # �chantillon X1
  Hill2opt = mean(log(X2[(m-koptX2+1):m]/X2opt))  # �chantillon X2 

  
     
# Calculs des log spacings 

  Y1 =  (1:koptX1) * log ( X1[n:(n-koptX1+1)] / X1[(n-1):(n-koptX1)]) 
  Y2 =  (1:koptX2) * log ( X2[m:(m-koptX2+1)] / X2[(m-1):(m-koptX2)])  

  # calcul des Sn2

  Sn1= mean((Y1-Hill1opt)^2)
  Sm2= mean((Y2-Hill2opt)^2)

  # calcul de muchap

  muchap[i] = (koptX1 * Hill1opt / Sn1 + koptX2 * Hill2opt / Sm2 ) / (koptX1 / Sn1 + koptX2 / Sm2 )

  #  construction de la matrice � donner en argument de EL.test

  # V= t( rbind( c(Y1-muchap[i],rep(0,koptX2)) , c(rep(0,koptX1),Y2-muchap[i]) ) )   

  # calcul de l(muchap,muchap) 

  #  elr=el.test(V,c(0,0),c(0,0))
  #  lmuchap[i]= elr$"-2LLR"


  # Calcul de la statistique de test Q(muchap)

  Qmuchap[i] = koptX1 *(Hill1opt-muchap[i])^2 / Sn1 + koptX2 *(Hill2opt- muchap[i])^2 / Sm2
  nb= nb+ (Qmuchap[i] > chideux1)

k1optimal[i] = koptX1
k2optimal[i] = koptX2

valkrhoopt1[i]=valkrho1
valkrhoopt2[i]=valkrho2
vecnbneg1[i]=nbneg1
vecchaprho1[i]=chaprho1
vecchaprho2[i]=chaprho2
vecHill1opt[i]=Hill1opt
vecHill2opt[i]=Hill2opt


} # fin for i=1: N  


# Evaluation de l'erreur de premi�re esp�ce (dans le cas o� H0 est vraie)

puissance = 100 * nb/N

